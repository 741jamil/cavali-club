import { useState, useRef } from "react";
import MenuHeader from "@/components/MenuHeader";
import MenuSection from "@/components/MenuSection";
import MenuQRCode from "@/components/MenuQRCode";
import FeaturedSection from "@/components/FeaturedSection";
import CategoryNav from "@/components/CategoryNav";
import ArtDecoBackground from "@/components/ArtDecoBackground";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  hotCoffee,
  tea,
  icedTea,
  freshJuices,
  cocktails,
  icedCoffee,
  frappe,
  mojitos,
  viennoiserie,
  softDrinks,
} from "@/data/menuData";

const Index = () => {
  const [activeCategory, setActiveCategory] = useState("featured");
  const { t, dir } = useLanguage();
  
  const sectionRefs = {
    featured: useRef<HTMLDivElement>(null),
    "hot-coffee": useRef<HTMLDivElement>(null),
    "iced-coffee": useRef<HTMLDivElement>(null),
    tea: useRef<HTMLDivElement>(null),
    "iced-tea": useRef<HTMLDivElement>(null),
    "fresh-juice": useRef<HTMLDivElement>(null),
    mojitos: useRef<HTMLDivElement>(null),
    sweets: useRef<HTMLDivElement>(null),
    drinks: useRef<HTMLDivElement>(null),
  };

  const handleCategoryChange = (categoryId: string) => {
    setActiveCategory(categoryId);
    const ref = sectionRefs[categoryId as keyof typeof sectionRefs];
    if (ref?.current) {
      const offset = 100;
      const elementPosition = ref.current.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({ top: offsetPosition, behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background relative" dir={dir}>
      {/* Art Deco Background Patterns */}
      <ArtDecoBackground />

      {/* Hero Header */}
      <div className="relative border-b border-border">
        <MenuHeader />
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 md:px-6 py-8">
        {/* Category Navigation */}
        <CategoryNav 
          activeCategory={activeCategory} 
          onCategoryChange={handleCategoryChange} 
        />

        {/* Featured Section */}
        <div ref={sectionRefs.featured}>
          <FeaturedSection />
        </div>

        {/* Menu Divider */}
        <div className="flex items-center justify-center my-12">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent to-border" />
          <div className="px-6 flex items-center gap-3">
            <div className="w-1 h-1 bg-primary rotate-45" />
            <span className="font-display text-foreground text-lg uppercase tracking-[0.3em]">
              {t("section.fullMenu")}
            </span>
            <div className="w-1 h-1 bg-primary rotate-45" />
          </div>
          <div className="flex-1 h-px bg-gradient-to-l from-transparent to-border" />
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-4">
          {/* Left Column */}
          <div>
            <div ref={sectionRefs["hot-coffee"]}>
              <MenuSection title={t("section.cafes")} items={hotCoffee} baseDelay={100} />
            </div>
            <div ref={sectionRefs.tea}>
              <MenuSection title={t("section.tea")} items={tea} baseDelay={150} />
            </div>
            <div ref={sectionRefs["iced-coffee"]}>
              <MenuSection title={t("section.icedCoffee")} items={icedCoffee} baseDelay={200} />
            </div>
            <div ref={sectionRefs["fresh-juice"]}>
              <MenuSection title={t("section.freshJuice")} items={freshJuices} baseDelay={250} />
            </div>
            <MenuSection title={t("section.cocktails")} items={cocktails} baseDelay={300} />
          </div>

          {/* Right Column */}
          <div>
            <div ref={sectionRefs["iced-tea"]}>
              <MenuSection title={t("section.icedTea")} items={icedTea} baseDelay={100} />
            </div>
            <MenuSection title={t("section.frappe")} items={frappe} baseDelay={150} />
            <div ref={sectionRefs.mojitos}>
              <MenuSection title={t("section.mojitos")} items={mojitos} baseDelay={200} />
            </div>
            <div ref={sectionRefs.sweets}>
              <MenuSection title={t("section.viennoiserie")} items={viennoiserie} baseDelay={250} />
            </div>
            <div ref={sectionRefs.drinks}>
              <MenuSection title={t("section.drinks")} items={softDrinks} baseDelay={300} />
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-20 pt-10 border-t border-border text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-8 h-px bg-primary/40" />
            <div className="w-1.5 h-1.5 bg-primary rotate-45" />
            <div className="w-8 h-px bg-primary/40" />
          </div>
          <p className="text-muted-foreground text-sm tracking-wide mb-2 font-body">
            {t("footer.prices")}
          </p>
          <p className="text-primary/40 text-xs font-display italic tracking-wider">
            {t("footer.thanks")}
          </p>
        </footer>
      </div>

      {/* QR Code */}
      <MenuQRCode url="https://kind-empathy-spark.lovable.app" />
    </div>
  );
};

export default Index;
